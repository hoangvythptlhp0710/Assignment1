import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.*;

public class BookManager {
    // TODO: your code here
    // attribute books

    public BookManager() {
        // TODO: your code here
    }

    public ArrayList<Book> getBooks() {
        // TODO: your code here
        return null;
    }

    /**
     * update this.books by reading books from file books.txt
     */
    public void loadFromFile() {
        System.out.println("Loading books...");

        // TODO: your code here
    }

    /**
     * print books (one/line) in required format
     */
    public void printBooks(ArrayList<Book> books) {
        // TODO: your code here
    }

    /**
     * if book.id is not duplicated, add book to this.books
     * return whether added or not
     */
    public boolean add(Book book) {
        // TODO: your code here
        return false;
    }

    /**
     * return book specified by id, null if not found
     */
    public Book getBookById(int id) {
        // TODO: your code here

        return null;
    }

    /**
     * delete book from this.books
     */
    public void delete(Book book) {
        // TODO: your code here
    }

    /**
     * update this.books to be sorted by price from high -> low
     */
    public void sortDescByPrice() {
        // TODO: your code here
    }

    /**
     * return all books having name contains keyword (case in-sensitive)
     */
    public ArrayList<Book> searchByName(String keyword) {
        ArrayList<Book> matches = new ArrayList<>();

        // TODO: your code here

        return matches;
    }

    /**
     * write this.books to file books.txt in required format
     */
    public void saveToFile() {
        // TODO: your code here
    }
}

public class Book {
    // TODO: your code here
    // attributes id, name, price

    // constructor
    public Book(int id, String name, double price) {
        // TODO: your code here
    }

    public void setName(String name) {
        // TODO: your code here
    }

    public void setPrice(double price) {
        // TODO: your code here
    }

    /**
     * return this as a String in the required format
     */
    @Override
    public String toString() {
        // TODO: your code here
        return null;
    }
}
